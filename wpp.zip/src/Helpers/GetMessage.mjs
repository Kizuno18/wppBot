import { getWalletBalance } from '../Modules/getWalletBalance/index.mjs';
import Offend from '../Modules/Offend/index.mjs';
import OpenIA from '../Modules/OpenIA/index.mjs';
import MidJourneiIA from "../Modules/MidJourneyIA/index.mjs";
import { exec } from 'child_process';
import kizuUtils from '../../lib/kizuUtils.js';
// IMPORTING MODULES
import db from '../../lib/database.js';
import bot from '../../lib/bot.js';
const { botInfo, botVerificarExpiracaoLimite } = bot;
import util from '../../lib/util.js';
const { criarTexto } = util;
import msgs_texto from '../../lib/msgs.js';
import { StickerCreate } from '../Modules/StickerBot/StickerBot.mjs';

const offendKeywords = [
  '!offend', '!ofenda', '!ofende', '!offenda', '!offende', '!ofender', '!offender',
  'offend', 'ofenda', 'ofende', 'offenda', 'offende', 'ofender', 'offender', '!xingar'
];

const cmdMsg = `
  !menu
  to see the entire menu.

  Extra commands:

  # <message>
  to talk with Chat GPT.

  !sticker <attach video or img>
  to create a sticker.

  !offend <mention contact>
  to offend someone else.

  !imagine <keyword>
  to generate an IA creative image.
`;

const msgSticker = `
  Você pode criar stickers automaticamente,
  enviando uma imagem, video ou gif no meu privado.

  Para stickers personalizados👇
  Digite: *!menu 1*
  _para saber os comandos de sticker._
`;

const registerMsg = (pushname, msg) => console.log(`${pushname} asked:\n${msg}\n`);
const infoMsg = async (message, msg) => message.reply(msg);

const checkLimit = async (sender, message, pushname) => {
  await botVerificarExpiracaoLimite()
  const ultrapassou = await db.ultrapassouLimite(sender);
  if (ultrapassou) {
    console.log("ultrapassou o Limite: "+sender)
    await infoMsg(message, criarTexto(msgs_texto.admin.limitediario.resposta_excedeu_limite, pushname));
    return true;
  }
  return false;
};
const handleChatMessage = async (sender, message, pushname) => {
  if (await checkLimit(sender, message, pushname)) {
    return;
  }
  await OpenIA(message);
  await db.addContagemDiaria(sender);
};

const handleCommandMessage = async (sender, message, pushname, body, type) => {
  switch (true) {
  case body.toLowerCase().startsWith('#') && type === 'chat':
    if (await checkLimit(sender, message, pushname)) {
      return
    }
  await handleChatMessage(sender, message, pushname);
  break;

  case body.toLowerCase().startsWith('!restart') && type === 'chat' && pushname === 'oBigLeo':
    await message.reply("restarting: "+body.toLowerCase().replace("!restart ",""))
    await kizuUtils.restart(body.toLowerCase().replace("!restart ",""));
    break;
  
  case body.toLowerCase() === '!sticker':
    if (await checkLimit(sender, message, pushname)) {
      return
    }
    await StickerCreate(message);
    break;
  
  case offendKeywords.some((keyword) => body.toLowerCase().startsWith(keyword)):
    if (await checkLimit(sender, message, pushname)) {
      return
    }
    registerMsg(pushname, body);
    await Offend(message);
    await db.addContagemDiaria(sender);
    break;
  
  case body.toLowerCase().startsWith('!imagine'):
    registerMsg(pushname, body);
    await MidJourneiIA(message);
    break;
  
  case body === '!credits' || body === '!creditos':
    registerMsg(pushname, body);
    await infoMsg(message, 'type !info');
    break;
  
  case body === '!commands' || body === '!comandos':
    registerMsg(pushname, body);
    await infoMsg(message, cmdMsg);
    break;
  }
  await db.addContagemTotal(sender);
  };
  
  export const messagesGetter = async (sender, message, type) => {
  try {
  const { body, caption } = message;
  var { pushname } = await message.getContact() || { pushname: '[Sem Nome]' };
  const chat = await message.getChat();

  if (await botInfo().limite_diario.status) {
    await botVerificarExpiracaoLimite();
  }
  
  // SE O USUARIO NÃO FOR REGISTRADO, FAÇA O REGISTRO
  var registrado = await db.verificarRegistro(sender)
  if(!registrado) {
        let user = await db.obterUsuario(sender), cmds_total = await user?.comandos_total || 0
        if (await user) {
          if (!pushname) pushname = "";
          if (!user.nome.toLowerCase().includes("cmds:")) { // verifica se o nome do contato contém "cmd" (case-insensitive) e se o objeto usuario não é nulo              
              let usernamer = `${user.nome ?? ''} cmds:${cmds_total}`;
             // console.log("user Registrado: " + usernamer);                    
              await db.registrarUsuario(sender, usernamer)
          } else await db.registrarUsuario(sender, pushname)
        }
  }     

  //SE FOR ALGUM COMANDO EXISTENTE
  //ATUALIZE NOME DO USUÁRIO
    let user = await db.obterUsuario(sender), cmds_total = await user?.comandos_total || 0
      if (await user) {
          if (pushname && !user.nome?.toLowerCase().includes("cmds:")) {        
             let usernamer = `${user.nome ?? ''} cmds:${cmds_total}`;
              await db.atualizarNome(sender, usernamer);
          }
          else await db.atualizarNome(sender, pushname);
      }
      
  
  if (!chat.isGroup && !body.toLowerCase().startsWith('!') && !body.toLowerCase().startsWith('#') && type === 'chat' && !message.fromMe) {
    await handleChatMessage(sender, message, pushname);
  } else {
    await handleCommandMessage(sender, message, pushname, body, type);
  }
} catch (error){ console.error(`An error occurred: ${error}`);
}
};  