const kizuUtils = require('./lib/kizuUtils.js');

kizuUtils.restart("run");