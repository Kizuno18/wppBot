import qrcode from "qrcode-terminal";
import { messagesGetter } from "./src/Helpers/GetMessage.js";

import whatsWeb from "whatsapp-web.js";
const { Client, LocalAuth } = whatsWeb;

export const whatsapp = new Client({
  authStrategy: new LocalAuth(),
  puppeteer: {
    args: ['--no-sandbox'],
    ffmpeg: './ffmpeg',
    executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
}
});

whatsapp.initialize();

whatsapp.on("qr", (qr) => {
  qrcode.generate(qr, { small: true });
});

whatsapp.on("authenticated", () => {
  console.log("Authentication complete");
});

whatsapp.on("ready", () => {
  console.log("Ready to accept messages");
});

whatsapp.on("message_create", async (message) => {
  const chat = await message.getChat();
  if (
    message.from !== "status@broadcast" &&
    message.broadcast === false && 
    chat.isGroup === true
  ) {
    messagesGetter(message, message.type);
  }
});



/* 
main().catch((err) => {
  console.error(err);
  process.exit(1);
});
 */
