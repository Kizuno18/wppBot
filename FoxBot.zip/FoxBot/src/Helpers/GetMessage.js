import Flamengo from "../Modules/Flamengo/index.js";
import MidJourneiIA from "../Modules/MidJourneyIA/index.js";
import Offend from "../Modules/Offend/index.js";
import OpenIA from "../Modules/OpenIA/index.js";
import {
    StickerCreate
} from "../Modules/StickerCreate/index.js"
import whatsappWeb from "whatsapp-web.js";
const {
    MessageMedia
} = whatsappWeb;

export const messagesGetter = async (message, type) => {
    
try {
    const contact = await message.getContact();
    const name = contact.pushname;
    const infoMsg = async (message, msg) => {
        message.reply(`${msg}`)
    };
    if (message.body.toLowerCase().startsWith("# ") && type === "chat") {
        console.log(name);
        console.log(message.body);
        OpenIA(message);
    }
    if (message._data.caption === '!sticker' || message.body.toLowerCase() === "!sticker") {
        console.log(name);
        console.log(message.body);
        console.log("\n");
        StickerCreate(message)
    }
    if (message.body.toLowerCase().startsWith('!offend')) {
        console.log(name);
        console.log(message.body);
        console.log("\n");
        Offend(message)
    }
    if (message.body.toLowerCase().startsWith('!imagine ')) {
        console.log(name);
        console.log(message.body);
        console.log("\n");
        MidJourneiIA(message)
    }
    if (message.body === '!foxMengo') {
        //Flamengo(message)
    }
    if (message.body === '!credits' || message.body === '!creditos') {
        console.log(name);
        console.log(message.body);
        console.log("\n");
        const msg = "The original Creator of Fox Bot is Rodrigo, dm me for more info.\n responderei assim que possivel."
        infoMsg(message, msg)
    }
    if (message.body === '!commands' || message.body === '!comandos') {
        console.log(name);
        console.log(message.body);
        console.log("\n");
        const msg = "# <message> \n to talk with Chat GPT.\n \n !sticker <attach video or img>\n to create a sticker.\n \n!offend <mention contact>\n to offend someone else.\n \n !imagine <keyword>\n to generate an IA creative image.\n\n !credits or !creditos\n to see bot info. \n\n !commands or !comandos \n to see the entire commands."
        infoMsg(message, msg)
    }

}

catch (error) {
    message.reply(`Ocorreu um erro: ${error}`);
  }
}



/* MESSAGEGETTER Message {
    _data: {
      id: {
        fromMe: true,
        remote: '120363049904243310@g.us',
        id: '3EB07B2E883F620C29DC',
        participant: '554498070146@c.us',
        _serialized: 'true_120363049904243310@g.us_3EB07B2E883F620C29DC_554498070146@c.us'
      },
      body: '!fox KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK',
      type: 'chat',
      t: 1675552635,
      notifyName: 'Rodrigo',
      from: '554498070146@c.us',
      to: '120363049904243310@g.us',
      self: 'in',
      ack: 1,
      isNewMsg: true,
      star: false,
      kicNotified: false,
      recvFresh: true,
      isFromTemplate: false,
      pollInvalidated: false,
      isSentCagPollCreation: false,
      latestEditMsgKey: null,
      latestEditSenderTimestampMs: null,
      broadcast: false,
      mentionedJidList: [],
      isVcardOverMmsDocument: false,
      isForwarded: false,
      hasReaction: false,
      productHeaderImageRejected: false,
      lastPlaybackProgress: 0,
      isDynamicReplyButtonsMsg: false,
      isMdHistoryMsg: false,
      stickerSentTs: 0,
      isAvatar: false,
      requiresDirectConnection: false,
      pttForwardedFeaturesEnabled: true,
      isEphemeral: false,
      isStatusV3: false,
      links: []
    },
    mediaKey: undefined,
    id: {
      fromMe: true,
      remote: '120363049904243310@g.us',
      id: '3EB07B2E883F620C29DC',
      participant: '554498070146@c.us',
      _serialized: 'true_120363049904243310@g.us_3EB07B2E883F620C29DC_554498070146@c.us'
    },
    ack: 1,
    hasMedia: false,
    body: '!fox KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK',
    type: 'chat',
    timestamp: 1675552635,
    from: '554498070146@c.us',
    to: '120363049904243310@g.us',
    author: undefined,
    deviceType: 'web',
    isForwarded: false,
    forwardingScore: 0,
    isStatus: false,
    isStarred: false,
    broadcast: false,
    fromMe: true,
    hasQuotedMsg: false,
    duration: undefined,
    location: undefined,
    vCards: [],
    inviteV4: undefined,
    mentionedIds: [],
    orderId: undefined,
    token: undefined,
    isGif: false,
    isEphemeral: false,
    links: []
  } */