import whatsappWeb from "whatsapp-web.js";
const { MessageMedia } = whatsappWeb;

const Flamengo = async (message) => {
    fetch('https://api.twitter.com/2/users/4829931538/tweets?max_results=10&expansions=attachments.media_keys&media.fields=preview_image_url,url', {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${process.env.BEARER_TOKEN_TWITTER}` 
        }})
    .then(r => r.json())
    .then(res => {
        const noticies = getKeys(res.data, res.includes.media)
        noticies.map(async ({ text, url }) => {
            if(url) {
                const chat = await message.getChat();
                const media = await MessageMedia.fromUrl(url);

                await chat.sendMessage(media, {caption: text}); 
            }else {
                message.reply(text); 
            }
        })
            
    })
    .catch(error => console.log(error))
}

function getKeys(obj1, obj2) {
    const texts = obj1.map(({ text }) => text)
    const urlImages = obj2.map(({ url, type }) => url)
    const combinedArray = texts.map((text, index) => ({
        text,
        url: urlImages[index] ?  urlImages[index] : '',
    }))
    console.log(combinedArray)
    return combinedArray; 
}

  
export default Flamengo