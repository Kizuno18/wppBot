import sendToOpenApi from '../../Helpers/api.js'



const OpenIA = async (message) => {
  try {
    const contact = await message.getContact();
    const name = contact.pushname;
    const response = await sendToOpenApi(message.body);
    console.log("response:");
    console.log(response);
console.log("\n"); try {message.reply(response);}
 catch (error) {message.reply(`Ocorreu um erro: ${error}`);}
  } catch (error) {
    message.reply(`Ocorreu um erro: ${error}`);
  }
};

export default OpenIA;
