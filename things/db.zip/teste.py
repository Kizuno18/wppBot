import json

# Abra o arquivo grupos.db e leia as linhas
with open('todosgrupos.db', 'r', encoding='utf-8') as f:
    linhas = f.readlines()

# Criar uma lista para os dados dos participantes
dados_participantes = []

# Iterar sobre cada linha
for linha in linhas:
    # Analisar a linha como JSON
    participantes = json.loads(linha)
    
    # Obter o ID do grupo, se houver
    if 'id_grupo' in participantes:
        id_grupo = participantes['id_grupo']
    else:
        continue
    
    # Iterar sobre a lista de participantes
    for participante in participantes['participantes']:
        # Criar um dicionário para o participante
        dados_participante = {
            'id_usuario': participante,
            'nome': participante + " cmds: 0",  # deixar vazio por enquanto
            'comandos_total': 0,
            'comandos_dia': 0,
            'max_comandos_dia': 25,
            'tipo': 'bronze',
            'id': 0,
            '_id': participante
        }
        
        # Adicionar o nome do participante ao dicionário
        #nome_participante = ''  # substitua essa linha pelo código que obtém o nome do participante
        #dados_participante['nome'] = nome_participante
        
        # Adicionar os dados do participante à lista
        dados_participantes.append(dados_participante)

# Salvar os dados dos participantes em outro arquivo
with open('output3.db', 'w') as f:
    for dados_participante in dados_participantes:
        f.write(json.dumps(dados_participante) + '\n')
