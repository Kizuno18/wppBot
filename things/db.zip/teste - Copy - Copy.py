import json
from multiprocessing.pool import ThreadPool

def process_line(line):
    if 'id_usuario' not in line:
        return None
    dados_participante = {
        'nome': line['id_usuario'] + " cmds: 0",  # adicionando nome com valor padrão
        'comandos_total': 0,  # adicionando comandos_total com valor padrão
        'comandos_dia': 0,  # adicionando comandos_dia com valor padrão
        'max_comandos_dia': 25,  # adicionando max_comandos_dia com valor padrão
        'tipo': 'bronze',  # adicionando tipo com valor padrão
        'id':  0,  # adicionando id com valor padrão
        '_id': line['id_usuario']
    }
    extra_args = ['nome', 'comandos_total', 'comandos_dia', 'max_comandos_dia', 'tipo', 'id', '_id']
    for arg in list(line.keys()):
        if not arg == "id_usuario":
         if arg not in dados_participante and arg not in extra_args:
            print(f"Argumento extra encontrado: {arg}={line[arg]}")
            del line[arg]  # removendo argumento extra
    return {"id_usuario": line["id_usuario"], **dados_participante}

with open('allDb.db', 'r', encoding='utf-8') as infile:
    lines = [json.loads(line) for line in infile if line.strip()]

pool = ThreadPool(4) # number of threads to use
processed_lines = pool.map(process_line, lines)
pool.close()
pool.join()

processed_lines = [line for line in processed_lines if line is not None]

with open('output2.db', 'w') as outfile:
    for line in processed_lines:
        outfile.write(json.dumps(line) + '\n')
